# Debug System Guide

## Tổng quan

Hệ thống debug được thiết kế để:
- ✅ Giữ lại tất cả test code và debug logs cho development
- ✅ Dễ dàng bật/tắt debug output
- ✅ Code vẫn professional và production-ready
- ✅ Không ảnh hưởng performance khi tắt debug

## Cấu trúc

### 1. Debug Macros (`ta/include/debug_config.h`)

```cpp
// Debug logs (có thể tắt)
DBG_LOG("Message");           // General debug
DBG_PARAM("Param info");     // Parameter logging
DBG_STEP(1, "Step message"); // Step-by-step
DBG_TEST("Test message");    // Test code logs

// Info/Error logs (luôn bật)
INFO_LOG("Info message");
WARN_LOG("Warning message");
ERROR_LOG("Error message");

// Performance timing (optional)
DBG_PERF_START();
// ... code ...
DBG_PERF_END("Operation name");

// Helper macro
FLUSH_LOGS_IF_AVAILABLE(params);
```

### 2. Debug Flags

Các flags được định nghĩa trong `ta/include/debug_config.h`:

| Flag | Mặc định | Mô tả |
|------|---------|-------|
| `DEBUG_ENABLED` | 1 | Bật/tắt tất cả debug logs |
| `DEBUG_PARAMS` | 1 | Log parameter types và values |
| `DEBUG_STEPS` | 1 | Log từng bước thực thi |
| `DEBUG_TEST_CODE` | 1 | Bật test code (memory access tests) |
| `DEBUG_PERF` | 0 | Bật performance timing |

## Cách sử dụng

### Development Mode (Mặc định)

Tất cả debug đã được bật sẵn:

```bash
./build.sh
```

Sẽ có đầy đủ:
- Parameter logging
- Step-by-step execution logs
- Test code (memory access verification)
- Debug messages

### Production Mode

Tắt tất cả debug để tối ưu performance:

```bash
make DEBUG_ENABLED=0
```

Hoặc chỉ tắt một số phần:

```bash
# Tắt test code nhưng giữ logs
make DEBUG_TEST_CODE=0

# Tắt step-by-step logs
make DEBUG_STEPS=0

# Bật performance timing
make DEBUG_PERF=1
```

### Custom Configuration

Tạo file `ta/Makefile.local`:

```makefile
DEBUG_ENABLED=1
DEBUG_PARAMS=1
DEBUG_STEPS=0
DEBUG_TEST_CODE=0
DEBUG_PERF=1
```

## Test Code

Test code được bao bởi `DBG_TEST_CODE()` macro:

```cpp
DBG_TEST_CODE({
    // Test shared memory read
    volatile uint32_t test_read = ctrl->head;
    DBG_TEST("Test read successful: 0x%08X", test_read);
    
    // Test shared memory write
    *test_ptr = 0xDEADBEEF;
    DBG_TEST("Test write successful");
});
```

Khi `DEBUG_TEST_CODE=0`, toàn bộ code trong block này sẽ bị loại bỏ hoàn toàn (zero overhead).

## Log Levels

### Debug Logs (Có thể tắt)
- `DBG_LOG()` - General debug information
- `DBG_PARAM()` - Parameter details
- `DBG_STEP()` - Step-by-step execution
- `DBG_TEST()` - Test code output

### Production Logs (Luôn bật)
- `INFO_LOG()` - Important information
- `WARN_LOG()` - Warnings
- `ERROR_LOG()` - Errors

## Performance Impact

### Debug Enabled
- Debug logs: ~1-2% overhead
- Test code: ~0.5% overhead (chỉ chạy trong init)
- Performance timing: ~0.1% overhead

### Debug Disabled
- Zero overhead (code được loại bỏ hoàn toàn bởi compiler)
- Chỉ giữ lại INFO/WARN/ERROR logs

## Best Practices

### 1. Sử dụng đúng macro

```cpp
// ✅ Đúng
INFO_LOG("LevelDB opened successfully");
DBG_LOG("Control pointer: %p", ctrl);

// ❌ Sai
OCALL_LOG("[INFO] LevelDB opened");  // Không có prefix tự động
```

### 2. Flush logs đúng cách

```cpp
// ✅ Đúng
FLUSH_LOGS_IF_AVAILABLE(params);

// ❌ Sai (verbose)
if (params[2].memref.buffer && params[2].memref.size > 0) {
    ocall_log_flush_to_params(params[2].memref.buffer, &params[2].memref.size);
}
```

### 3. Test code trong init phase

```cpp
DBG_TEST_CODE({
    // Chỉ test trong init, không test trong hot path
    DBG_TEST("Testing shared memory access...");
    // ... test code ...
});
```

## Examples

### Example 1: Development với đầy đủ debug

```bash
# Build với tất cả debug
./build.sh

# Output sẽ có:
# [DEBUG] Param types: p0=6, p1=1, p2=5, p3=0
# [STEP 1] Starting Ring Buffer initialization
# [TEST] Testing shared memory read access...
# [TEST] Test read successful, current head value: 0x00000000
# [INFO] Ring Buffer initialized
```

### Example 2: Production build

```bash
# Build production (tắt debug)
make DEBUG_ENABLED=0

# Output chỉ có:
# [INFO] Ring Buffer initialized
# [INFO] LevelDB opened successfully
```

### Example 3: Performance profiling

```bash
# Build với performance timing
make DEBUG_PERF=1

# Output sẽ có:
# [PERF] DB::Open: 1234 ms
# [PERF] DB::Put: 5 ms
```

## Troubleshooting

### Debug logs không xuất hiện

1. Kiểm tra `DEBUG_ENABLED` flag:
   ```bash
   grep DEBUG_ENABLED ta/sub.mk
   ```

2. Kiểm tra log buffer size trong host app

3. Đảm bảo `ocall_log_flush_to_params()` được gọi

### Test code không chạy

1. Kiểm tra `DEBUG_TEST_CODE` flag:
   ```bash
   make DEBUG_TEST_CODE=1
   ```

2. Test code chỉ chạy trong init phase, không chạy trong PUT/GET

### Performance bị ảnh hưởng

1. Tắt debug trong production:
   ```bash
   make DEBUG_ENABLED=0
   ```

2. Chỉ giữ lại ERROR logs:
   ```bash
   make DEBUG_ENABLED=0 DEBUG_PARAMS=0 DEBUG_STEPS=0 DEBUG_TEST_CODE=0
   ```

## Migration từ OCALL_LOG

### Trước (old code):
```cpp
OCALL_LOG("[DEBUG] Param types: p0=%d", p0);
OCALL_LOG("[INFO] LevelDB opened");
OCALL_LOG("[ERROR] Failed to open");
```

### Sau (new code):
```cpp
DBG_PARAM("Param types: p0=%d", p0);
INFO_LOG("LevelDB opened");
ERROR_LOG("Failed to open");
```

## Summary

- ✅ **Development**: Tất cả debug bật sẵn, code dễ debug
- ✅ **Production**: Tắt debug = zero overhead
- ✅ **Flexible**: Có thể bật/tắt từng phần
- ✅ **Professional**: Code structure vẫn clean và maintainable

