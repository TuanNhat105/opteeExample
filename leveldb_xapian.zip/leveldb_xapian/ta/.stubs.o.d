stubs.o: stubs.cpp \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stddef.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/string.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/features.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/strings.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdlib.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/alloca.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/types.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/endian.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/__endian.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/select.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/sysmacros.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_internal_api.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/compiler.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_defines.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_types.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/inttypes.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdbool.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/trace.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdarg.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/trace_levels.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_compat.h
../../eevm_minimal_ta/build_oe_libs/musl/include/stddef.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/string.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/features.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/strings.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdlib.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/alloca.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/types.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/endian.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/__endian.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/select.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/sysmacros.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_internal_api.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/compiler.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_defines.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_types.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/inttypes.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdbool.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/trace.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdarg.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/trace_levels.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_compat.h:
