user_ta_header.o: \
 /home/orangepi/tee-core/export-ta_arm64/src/user_ta_header.c \
 /home/orangepi/tee-core/export-ta_arm64/include/compiler.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/malloc.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h \
 /home/orangepi/tee-core/export-ta_arm64/include/tee_ta_api.h \
 /home/orangepi/tee-core/export-ta_arm64/include/tee_api_defines.h \
 /home/orangepi/tee-core/export-ta_arm64/include/tee_api_types.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/inttypes.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/features.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdbool.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stddef.h \
 /home/orangepi/tee-core/export-ta_arm64/include/tee_internal_api_extensions.h \
 /home/orangepi/tee-core/export-ta_arm64/include/trace.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdarg.h \
 /home/orangepi/tee-core/export-ta_arm64/include/trace_levels.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdio.h \
 /home/orangepi/tee-core/export-ta_arm64/include/tee_api_defines_extensions.h \
 /home/orangepi/tee-core/export-ta_arm64/include/user_ta_header.h \
 /home/orangepi/tee-core/export-ta_arm64/include/util.h \
 user_ta_header_defines.h ../../eevm_minimal_ta/build_libunwind/config.h \
 eevm_ta.h \
 /home/orangepi/tee-core/export-ta_arm64/include/utee_syscalls.h \
 /home/orangepi/tee-core/export-ta_arm64/include/utee_types.h
