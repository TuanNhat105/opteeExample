user_ta_header.o: \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/src/user_ta_header.c \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/compiler.h \
 ../../eevm_minimal_ta/build_libunwind/config.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/malloc.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_ta_api.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_internal_api.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stddef.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_defines.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_types.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/inttypes.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/features.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdbool.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/trace.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdarg.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/trace_levels.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_compat.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_internal_api_extensions.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdio.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_defines_extensions.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/user_ta_header.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/util.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/assert.h \
 user_ta_header_defines.h eevm_ta.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/utee_syscalls.h \
 /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/utee_types.h
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/compiler.h:
../../eevm_minimal_ta/build_libunwind/config.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/malloc.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_ta_api.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_internal_api.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stddef.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_defines.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_types.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/inttypes.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/features.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdbool.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/trace.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdarg.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/trace_levels.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_compat.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_internal_api_extensions.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdio.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/tee_api_defines_extensions.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/user_ta_header.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/util.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/assert.h:
user_ta_header_defines.h:
eevm_ta.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/utee_syscalls.h:
/home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/include/utee_types.h:
