// SPDX-License-Identifier: BSD-2-Clause
/*
 * LevelDB with Ring Buffer - OP-TEE Trusted Application
 * 
 * Uses real LevelDB from Google with custom RingBufferEnv:
 * - LevelDB data stored in RAM (MemoryFile) - no disk I/O
 * - Data sent to Normal World via ring buffer
 * - Simple ring buffer for real-time logging
 */

// Include C++ headers BEFORE TEE headers
#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>
#include <memory>
#include <cstring>
#include <cstdio>

// LevelDB headers
#include <leveldb/db.h>
#include <leveldb/options.h>
#include <leveldb/write_batch.h>

// TEE headers
extern "C"
{
#include <tee_internal_api.h>
#include <tee_internal_api_extensions.h>
}

#include "eevm_ta.h"
#include "ocall_logger.h"
#include "simple_shared_ring_buffer.h"
#include "secure_ring_buffer_producer.hpp"
#include "leveldb_ring_buffer_env_complete.hpp"
#include "../include/shared_ring_buffer.hpp"

// Helper function to write to ring buffer (TA side - Producer)
static void write_to_ring_buffer(struct SharedRingBuffer* rb, const char* data, size_t len) {
    if (!rb || !data || len == 0) return;
    
    // Validate ring buffer structure
    if (rb->size == 0 || rb->size > 1024 * 1024) { // Sanity check: 0 < size <= 1MB
        DMSG("ERROR: Invalid ring buffer size: %u", rb->size);
        return;
    }
    
    for (size_t i = 0; i < len; i++) {
        // Read current head and tail (with memory barrier)
        __asm__ volatile("dmb ish" ::: "memory");
        uint32_t current_head = rb->head;
        uint32_t current_tail = rb->tail;
        __asm__ volatile("dmb ish" ::: "memory");
        
        uint32_t next_head = (current_head + 1) % rb->size;
        
        // Check if buffer is full (head would catch up to tail)
        if (next_head == current_tail) {
            // Buffer full - skip this byte
            // DMSG("WARN: Ring buffer full, skipping byte");
            continue;
        }
        
        // Write byte to buffer
        rb->data[current_head] = data[i];
        
        // Memory barrier: Ensure data is written to RAM before updating head
        __asm__ volatile("dmb ish" ::: "memory");
        
        // Update head
        rb->head = next_head;
        // Memory barrier - cache clean may cause issues, use simple barrier for now
        __asm__ volatile("dmb ish" ::: "memory");
    }
}


// =====================================================================
// SIMPLE TEST: Test TEEC_InvokeCommand with Shared Memory (NO LevelDB)
// =====================================================================

/*
 * Simple test command with ring buffer
 * 
 * params[0] = MEMREF_INOUT - Ring buffer (for real-time logging)
 * params[1] = VALUE_INPUT  - Test value (not used, kept for compatibility)
 * params[2] = VALUE_INPUT  - Test value
 * params[3] = MEMREF_OUTPUT - OCALL logs
 */
static TEE_Result test_simple_shm(uint32_t param_types, TEE_Param params[4])
{
    
    // Initialize logging
    ocall_log_init();
    
    // Check parameter types
    uint32_t p0 = TEE_PARAM_TYPE_GET(param_types, 0);
    uint32_t p1 = TEE_PARAM_TYPE_GET(param_types, 1);
    uint32_t p2 = TEE_PARAM_TYPE_GET(param_types, 2);
    uint32_t p3 = TEE_PARAM_TYPE_GET(param_types, 3);
    
    DMSG("p0=0x%X, p1=0x%X, p2=0x%X, p3=0x%X", p0, p1, p2, p3);
    
    // Param 0: Ring buffer (MEMREF)
    if (p0 != TEE_PARAM_TYPE_MEMREF_INOUT && 
        p0 != TEE_PARAM_TYPE_MEMREF_INPUT && 
        p0 != TEE_PARAM_TYPE_MEMREF_OUTPUT) {
        DMSG("ERROR: Invalid param 0 type: 0x%X", p0);
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    // Param 1: Test value (VALUE_INPUT) - optional, kept for compatibility
    // Param 2: Test value (VALUE_INPUT)
    if (p2 != TEE_PARAM_TYPE_VALUE_INPUT) {
        DMSG("ERROR: Invalid param 2 type: 0x%X", p2);
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    // Validate ring buffer
    if (!params[0].memref.buffer || params[0].memref.size == 0) {
        DMSG("ERROR: Invalid ring buffer");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    DMSG("Ring buffer: buffer=%p, size=%u", 
         params[0].memref.buffer, params[0].memref.size);
    DMSG("Test value: %u", params[2].value.a);
    
    // Validate ring buffer structure first
    if (params[0].memref.size < sizeof(struct SharedRingBuffer)) {
        DMSG("ERROR: Ring buffer too small: %u < %zu", 
             params[0].memref.size, sizeof(struct SharedRingBuffer));
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    // Get ring buffer and data shared memory
    // Use simple memory barrier instead of cache invalidation to avoid crashes
    __asm__ volatile("dmb ish" ::: "memory");
    
    struct SharedRingBuffer* rb = static_cast<struct SharedRingBuffer*>(params[0].memref.buffer);
    
    // Initialize ring buffer structure if needed (simple approach)
    // Calculate data buffer size
    uint32_t data_buffer_size = params[0].memref.size - sizeof(struct SharedRingBuffer);
    
    // Read current values with memory barrier
    __asm__ volatile("dmb ish" ::: "memory");
    uint32_t rb_size = rb->size;
    uint32_t rb_head = rb->head;
    uint32_t rb_tail = rb->tail;
    __asm__ volatile("dmb ish" ::: "memory");
    
    DMSG("Ring buffer initial state: head=%u, tail=%u, size=%u, data_buffer_size=%u", 
         rb_head, rb_tail, rb_size, data_buffer_size);
    
    // Initialize if not initialized or invalid
    if (rb_size == 0 || rb_size > data_buffer_size || rb_size > 1024 * 1024) {
        DMSG("Initializing ring buffer: old_size=%u, new_size=%u", rb_size, data_buffer_size);
        
        // Simple initialization - just set size, head and tail should already be 0
        rb->size = data_buffer_size;
        
        // Memory barrier
        __asm__ volatile("dmb ish" ::: "memory");
        
        DMSG("Ring buffer initialized: size=%u", rb->size);
    }
    
    
    // Write real-time logs to ring buffer (không cần đợi command kết thúc)
    // Only write if ring buffer is valid and large enough
    bool use_ring_buffer = (rb != nullptr) && 
                           (params[0].memref.size >= sizeof(struct SharedRingBuffer) + 1024) &&
                           (rb->size > 0) && 
                           (rb->size <= params[0].memref.size - sizeof(struct SharedRingBuffer));
    
    if (use_ring_buffer) {
        char log_msg[256];
        snprintf(log_msg, sizeof(log_msg), 
                 "[RING] test_simple_shm: Starting...\n");
        write_to_ring_buffer(rb, log_msg, strlen(log_msg));
        
        // Simulate some processing with real-time updates
        for (int i = 0; i < 5; i++) {
            snprintf(log_msg, sizeof(log_msg), 
                     "[RING] Processing step %d/5, test_value=%u\n", i+1, params[2].value.a);
            write_to_ring_buffer(rb, log_msg, strlen(log_msg));
            
            // Small delay to simulate work
            TEE_Time start, end;
            TEE_GetSystemTime(&start);
            do {
                TEE_GetSystemTime(&end);
            } while ((end.seconds - start.seconds) * 1000 + 
                     (end.millis - start.millis) < 50); // ~50ms delay
        }
        
        
        write_to_ring_buffer(rb, "[RING] test_simple_shm: SUCCESS\n", 33);
    } else {
        DMSG("WARN: Ring buffer invalid, skipping real-time logging");
    }
    
    OCALL_LOG("=== test_simple_shm SUCCESS ===");
    OCALL_LOG("Test value received: %u", params[2].value.a);
    
    // Flush logs
    if (params[3].memref.buffer && params[3].memref.size > 0) {
        ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
    }
    return TEE_SUCCESS;
}

// =====================================================================
// LEVELDB OPERATIONS WITH RING BUFFER
// =====================================================================

// Global variables for LevelDB
static std::unique_ptr<leveldb::DB> g_db;
static std::unique_ptr<SecureRingBufferProducer> g_producer;
static std::unique_ptr<RingBufferEnv> g_env;
static void* g_leveldb_shared_mem = nullptr;

// Simple ring buffer for logging (separate from LevelDB data ring buffer)
static struct SharedRingBuffer* g_log_ring_buffer = nullptr;

/*
 * Initialize LevelDB with Ring Buffer
 * 
 * params[0] = MEMREF_WHOLE - LevelDB data ring buffer (RingBufferControl)
 * params[1] = MEMREF_WHOLE - Logging ring buffer (SharedRingBuffer)
 * params[2] = VALUE_INPUT  - LevelDB buffer size
 * params[3] = MEMREF_TEMP_OUTPUT - OCALL logs
 */
static TEE_Result leveldb_init(uint32_t param_types, TEE_Param params[4])
{
    ocall_log_init();
    OCALL_LOG("=== Initializing LevelDB with Ring Buffer ===");
    
    uint32_t p0 = TEE_PARAM_TYPE_GET(param_types, 0);
    uint32_t p1 = TEE_PARAM_TYPE_GET(param_types, 1);
    uint32_t p2 = TEE_PARAM_TYPE_GET(param_types, 2);
    uint32_t p3 = TEE_PARAM_TYPE_GET(param_types, 3);
    
    if (p0 != TEE_PARAM_TYPE_MEMREF_INOUT && 
        p0 != TEE_PARAM_TYPE_MEMREF_INPUT && 
        p0 != TEE_PARAM_TYPE_MEMREF_OUTPUT) {
        OCALL_LOG("[ERROR] Invalid param 0 type: 0x%X", p0);
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (p1 != TEE_PARAM_TYPE_MEMREF_INOUT && 
        p1 != TEE_PARAM_TYPE_MEMREF_INPUT && 
        p1 != TEE_PARAM_TYPE_MEMREF_OUTPUT) {
        OCALL_LOG("[ERROR] Invalid param 1 type: 0x%X", p1);
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (p2 != TEE_PARAM_TYPE_VALUE_INPUT) {
        OCALL_LOG("[ERROR] Invalid param 2 type: 0x%X", p2);
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (!params[0].memref.buffer || params[0].memref.size == 0) {
        OCALL_LOG("[ERROR] Invalid LevelDB ring buffer");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (!params[1].memref.buffer || params[1].memref.size == 0) {
        OCALL_LOG("[ERROR] Invalid logging ring buffer");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    try {
        // Setup logging ring buffer (simple)
        __asm__ volatile("dmb ish" ::: "memory");
        g_log_ring_buffer = static_cast<struct SharedRingBuffer*>(params[1].memref.buffer);
        
        if (params[1].memref.size < sizeof(struct SharedRingBuffer)) {
            OCALL_LOG("[ERROR] Logging ring buffer too small");
            return TEE_ERROR_BAD_PARAMETERS;
        }
        
        uint32_t log_data_size = params[1].memref.size - sizeof(struct SharedRingBuffer);
        if (g_log_ring_buffer->size == 0 || g_log_ring_buffer->size > log_data_size) {
            g_log_ring_buffer->size = log_data_size;
            __asm__ volatile("dmb ish" ::: "memory");
        }
        
        // Setup LevelDB data ring buffer (complex - RingBufferControl)
        g_leveldb_shared_mem = params[0].memref.buffer;
        uint32_t leveldb_buffer_size = params[2].value.a;
        
        if (params[0].memref.size < sizeof(RingBufferControl)) {
            OCALL_LOG("[ERROR] LevelDB ring buffer too small: %u < %zu", 
                     params[0].memref.size, sizeof(RingBufferControl));
            return TEE_ERROR_BAD_PARAMETERS;
        }
        
        OCALL_LOG("[INFO] LevelDB shared memory: %p, Buffer size: %u", 
                 g_leveldb_shared_mem, leveldb_buffer_size);
        
        // Initialize Ring Buffer Control
        auto* ctrl = static_cast<RingBufferControl*>(g_leveldb_shared_mem);
        ctrl->head = 0;
        ctrl->tail = 0;
        ctrl->last_flushed_id = 0;
        ctrl->sync_counter = 0;
        ctrl->buffer_size = leveldb_buffer_size - sizeof(RingBufferControl);
        
        __asm__ volatile("dmb ish" ::: "memory");
        
        OCALL_LOG("[INFO] LevelDB ring buffer initialized - Data buffer size: %u", ctrl->buffer_size);
        
        // Create Ring Buffer Producer
        OCALL_LOG("[DEBUG] Creating SecureRingBufferProducer...");
        try {
            g_producer = std::make_unique<SecureRingBufferProducer>(g_leveldb_shared_mem, leveldb_buffer_size);
            OCALL_LOG("[INFO] Ring Buffer Producer created");
        } catch (const std::exception& e) {
            OCALL_LOG("[EXCEPTION] Failed to create SecureRingBufferProducer: %s", e.what());
            return TEE_ERROR_GENERIC;
        } catch (...) {
            OCALL_LOG("[EXCEPTION] Unknown exception creating SecureRingBufferProducer");
            return TEE_ERROR_GENERIC;
        }
        
        // Create custom LevelDB environment (in-memory, no disk)
        DMSG("DEBUG: About to create RingBufferEnv");
        OCALL_LOG("[DEBUG] Creating RingBufferEnv...");
        
        // Flush logs before creating RingBufferEnv
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        
        DMSG("DEBUG: Before make_unique<RingBufferEnv>");
        
        // Create RingBufferEnv (using std::map - supported in your environment)
        // Note: If exception is thrown, it may not be caught if exception handling is not fully supported
        // But std::map itself should work if you have exception support
        try {
            DMSG("DEBUG: Calling make_unique<RingBufferEnv>");
            g_env = std::make_unique<RingBufferEnv>(g_producer.get());
            DMSG("DEBUG: RingBufferEnv created successfully");
            OCALL_LOG("[INFO] LevelDB Ring Buffer Env created (in-memory + ring buffer)");
        } catch (const std::bad_alloc& e) {
            DMSG("ERROR: std::bad_alloc in RingBufferEnv creation");
            OCALL_LOG("[EXCEPTION] Out of memory creating RingBufferEnv");
            g_producer.reset();
            if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
                params[3].memref.buffer && params[3].memref.size > 0) {
                ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
            }
            return TEE_ERROR_OUT_OF_MEMORY;
        } catch (const std::exception& e) {
            DMSG("ERROR: std::exception in RingBufferEnv creation");
            OCALL_LOG("[EXCEPTION] Failed to create RingBufferEnv");
            g_producer.reset();
            if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
                params[3].memref.buffer && params[3].memref.size > 0) {
                ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
            }
            return TEE_ERROR_GENERIC;
        } catch (...) {
            DMSG("ERROR: Unknown exception in RingBufferEnv creation");
            OCALL_LOG("[EXCEPTION] Unknown exception creating RingBufferEnv");
            g_producer.reset();
            if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
                params[3].memref.buffer && params[3].memref.size > 0) {
                ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
            }
            return TEE_ERROR_GENERIC;
        }
        
        DMSG("DEBUG: After RingBufferEnv creation");
        
        // Flush logs after RingBufferEnv creation
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        
        // Open LevelDB with custom environment
        DMSG("DEBUG: Setting up LevelDB options");
        leveldb::Options options;
        options.env = g_env.get();
        options.create_if_missing = true;
        options.write_buffer_size = 512 * 1024; // 512KB
        options.max_open_files = 50;
        options.block_cache = nullptr; // Disable cache to save memory
        options.compression = leveldb::kNoCompression;
        
        DMSG("DEBUG: Options configured, about to call DB::Open");
        OCALL_LOG("[DEBUG] About to call leveldb::DB::Open()...");
        
        // Flush logs before DB::Open (may take time)
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        
        DMSG("DEBUG: Before DB::Open call");
        leveldb::DB* db_ptr = nullptr;
        leveldb::Status status;
        
        try {
            DMSG("DEBUG: Calling leveldb::DB::Open()");
            status = leveldb::DB::Open(options, "/tmp/leveldb_secure", &db_ptr);
            DMSG("DEBUG: DB::Open() returned");
        } catch (const std::bad_alloc& e) {
            DMSG("ERROR: std::bad_alloc in DB::Open()");
            OCALL_LOG("[EXCEPTION] Out of memory in DB::Open()");
            if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
                params[3].memref.buffer && params[3].memref.size > 0) {
                ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
            }
            return TEE_ERROR_OUT_OF_MEMORY;
        } catch (const std::exception& e) {
            DMSG("ERROR: std::exception in DB::Open()");
            OCALL_LOG("[EXCEPTION] Exception in DB::Open(): %s", e.what());
            if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
                params[3].memref.buffer && params[3].memref.size > 0) {
                ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
            }
            return TEE_ERROR_GENERIC;
        } catch (...) {
            DMSG("ERROR: Unknown exception in DB::Open()");
            OCALL_LOG("[EXCEPTION] Unknown exception in DB::Open()");
            if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
                params[3].memref.buffer && params[3].memref.size > 0) {
                ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
            }
            return TEE_ERROR_GENERIC;
        }
        
        DMSG("DEBUG: Checking DB::Open status");
        if (!status.ok()) {
            DMSG("ERROR: DB::Open failed: %s", status.ToString().c_str());
            OCALL_LOG("[ERROR] Failed to open LevelDB: %s", status.ToString().c_str());
            if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
                params[3].memref.buffer && params[3].memref.size > 0) {
                ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
            }
            return TEE_ERROR_GENERIC;
        }
        
        DMSG("DEBUG: DB::Open succeeded, resetting g_db");
        g_db.reset(db_ptr);
        DMSG("DEBUG: LevelDB opened successfully");
        OCALL_LOG("[INFO] LevelDB opened successfully!");
        
        // Log to simple ring buffer
        char log_msg[256];
        snprintf(log_msg, sizeof(log_msg), 
                 "[RING] LevelDB initialized successfully (in-memory, no disk)\n");
        write_to_ring_buffer(g_log_ring_buffer, log_msg, strlen(log_msg));
        
        // Flush logs
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        
        return TEE_SUCCESS;
        
    } catch (const std::bad_alloc& e) {
        OCALL_LOG("[EXCEPTION] Out of memory: %s", e.what());
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        return TEE_ERROR_OUT_OF_MEMORY;
    } catch (const std::exception& e) {
        OCALL_LOG("[EXCEPTION] %s", e.what());
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        return TEE_ERROR_GENERIC;
    } catch (...) {
        OCALL_LOG("[EXCEPTION] Unknown exception during init!");
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        return TEE_ERROR_GENERIC;
    }
}

/*
 * Put a key-value pair into LevelDB
 * 
 * params[0] = MEMREF_TEMP_INPUT  - Key
 * params[1] = MEMREF_TEMP_INPUT  - Value
 * params[2] = VALUE_OUTPUT       - Status code (0=success, 1=error)
 * params[3] = MEMREF_TEMP_OUTPUT - OCALL logs (optional)
 */
static TEE_Result leveldb_put(uint32_t param_types, TEE_Param params[4])
{
    ocall_log_init();
    
    uint32_t p0 = TEE_PARAM_TYPE_GET(param_types, 0);
    uint32_t p1 = TEE_PARAM_TYPE_GET(param_types, 1);
    uint32_t p2 = TEE_PARAM_TYPE_GET(param_types, 2);
    uint32_t p3 = TEE_PARAM_TYPE_GET(param_types, 3);
    
    if (p0 != TEE_PARAM_TYPE_MEMREF_INPUT || 
        p1 != TEE_PARAM_TYPE_MEMREF_INPUT ||
        p2 != TEE_PARAM_TYPE_VALUE_OUTPUT) {
        OCALL_LOG("[ERROR] Bad parameter types!");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (!params[0].memref.buffer || params[0].memref.size == 0 ||
        !params[1].memref.buffer || params[1].memref.size == 0) {
        OCALL_LOG("[ERROR] Invalid key or value buffer!");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (!g_db) {
        OCALL_LOG("[ERROR] LevelDB not initialized!");
        return TEE_ERROR_BAD_STATE;
    }
    
    try {
        std::string key(static_cast<const char*>(params[0].memref.buffer), 
                        params[0].memref.size);
        std::string value(static_cast<const char*>(params[1].memref.buffer), 
                          params[1].memref.size);
        
        // Log to simple ring buffer
        if (g_log_ring_buffer) {
            char log_msg[256];
            snprintf(log_msg, sizeof(log_msg), 
                     "[RING] PUT: key='%s', value_size=%zu\n", 
                     key.c_str(), value.size());
            write_to_ring_buffer(g_log_ring_buffer, log_msg, strlen(log_msg));
        }
        
        // Use LevelDB thật
        leveldb::WriteOptions write_options;
        write_options.sync = false; // No sync needed (in-memory)
        
        leveldb::Status status = g_db->Put(write_options, key, value);
        
        if (status.ok()) {
            OCALL_LOG("[INFO] PUT successful: key='%s'", key.c_str());
            params[2].value.a = 0;
        } else {
            OCALL_LOG("[ERROR] PUT failed: %s", status.ToString().c_str());
            params[2].value.a = 1;
        }
        
        // Flush logs
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        
        return TEE_SUCCESS;
        
    } catch (const std::exception& e) {
        OCALL_LOG("[EXCEPTION] %s", e.what());
        params[2].value.a = 1;
        
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        return TEE_ERROR_GENERIC;
    }
}

/*
 * Get a value from LevelDB by key
 * 
 * params[0] = MEMREF_TEMP_INPUT  - Key
 * params[1] = MEMREF_TEMP_OUTPUT - Value
 * params[2] = VALUE_OUTPUT       - Status code (0=found, 1=not found, 2=error)
 * params[3] = MEMREF_TEMP_OUTPUT - OCALL logs (optional)
 */
static TEE_Result leveldb_get(uint32_t param_types, TEE_Param params[4])
{
    ocall_log_init();
    
    uint32_t p0 = TEE_PARAM_TYPE_GET(param_types, 0);
    uint32_t p1 = TEE_PARAM_TYPE_GET(param_types, 1);
    uint32_t p2 = TEE_PARAM_TYPE_GET(param_types, 2);
    uint32_t p3 = TEE_PARAM_TYPE_GET(param_types, 3);
    
    if (p0 != TEE_PARAM_TYPE_MEMREF_INPUT || 
        p1 != TEE_PARAM_TYPE_MEMREF_OUTPUT ||
        p2 != TEE_PARAM_TYPE_VALUE_OUTPUT) {
        OCALL_LOG("[ERROR] Bad parameter types!");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (!params[0].memref.buffer || params[0].memref.size == 0 ||
        !params[1].memref.buffer || params[1].memref.size == 0) {
        OCALL_LOG("[ERROR] Invalid key or value buffer!");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (!g_db) {
        OCALL_LOG("[ERROR] LevelDB not initialized!");
        return TEE_ERROR_BAD_STATE;
    }
    
    try {
        std::string key(static_cast<const char*>(params[0].memref.buffer), 
                        params[0].memref.size);
        
        // Log to simple ring buffer
        if (g_log_ring_buffer) {
            char log_msg[256];
            snprintf(log_msg, sizeof(log_msg), "[RING] GET: key='%s'\n", key.c_str());
            write_to_ring_buffer(g_log_ring_buffer, log_msg, strlen(log_msg));
        }
        
        // Use LevelDB thật
        std::string value;
        leveldb::Status status = g_db->Get(leveldb::ReadOptions(), key, &value);
        
        if (status.ok()) {
            // Found - copy value to output buffer
            size_t copy_size = std::min(value.size(), 
                                       static_cast<size_t>(params[1].memref.size));
            if (copy_size > 0) {
                memcpy(params[1].memref.buffer, value.data(), copy_size);
            }
            params[1].memref.size = static_cast<uint32_t>(copy_size);
            params[2].value.a = 0;
            
            OCALL_LOG("[INFO] GET successful: key='%s', value_size=%zu", 
                     key.c_str(), copy_size);
        } else if (status.IsNotFound()) {
            // Not found
            params[1].memref.size = 0;
            params[2].value.a = 1;
            
            OCALL_LOG("[INFO] Key not found: '%s'", key.c_str());
        } else {
            // Error
            params[2].value.a = 2;
            OCALL_LOG("[ERROR] GET failed: %s", status.ToString().c_str());
        }
        
        // Flush logs
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        
        return TEE_SUCCESS;
        
    } catch (const std::exception& e) {
        OCALL_LOG("[EXCEPTION] %s", e.what());
        params[2].value.a = 2;
        
        if (p3 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[3].memref.buffer && params[3].memref.size > 0) {
            ocall_log_flush_to_params(params[3].memref.buffer, &params[3].memref.size);
        }
        return TEE_ERROR_GENERIC;
    }
}

/*
 * Delete a key from LevelDB
 * 
 * params[0] = MEMREF_TEMP_INPUT  - Key
 * params[1] = VALUE_OUTPUT       - Status code (0=success, 1=error)
 * params[2] = MEMREF_TEMP_OUTPUT - OCALL logs (optional)
 * params[3] = NONE
 */
static TEE_Result leveldb_delete(uint32_t param_types, TEE_Param params[4])
{
    ocall_log_init();
    
    uint32_t p0 = TEE_PARAM_TYPE_GET(param_types, 0);
    uint32_t p1 = TEE_PARAM_TYPE_GET(param_types, 1);
    uint32_t p2 = TEE_PARAM_TYPE_GET(param_types, 2);
    
    if (p0 != TEE_PARAM_TYPE_MEMREF_INPUT || 
        p1 != TEE_PARAM_TYPE_VALUE_OUTPUT) {
        OCALL_LOG("[ERROR] Bad parameter types!");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (!params[0].memref.buffer || params[0].memref.size == 0) {
        OCALL_LOG("[ERROR] Invalid key buffer!");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (!g_db) {
        OCALL_LOG("[ERROR] LevelDB not initialized!");
        return TEE_ERROR_BAD_STATE;
    }
    
    try {
        std::string key(static_cast<const char*>(params[0].memref.buffer), 
                        params[0].memref.size);
        
        // Log to simple ring buffer
        if (g_log_ring_buffer) {
            char log_msg[256];
            snprintf(log_msg, sizeof(log_msg), "[RING] DELETE: key='%s'\n", key.c_str());
            write_to_ring_buffer(g_log_ring_buffer, log_msg, strlen(log_msg));
        }
        
        // Use LevelDB thật
        leveldb::WriteOptions write_options;
        write_options.sync = false;
        
        leveldb::Status status = g_db->Delete(write_options, key);
        
        if (status.ok()) {
            OCALL_LOG("[INFO] DELETE successful: key='%s'", key.c_str());
            params[1].value.a = 0;
        } else {
            OCALL_LOG("[ERROR] DELETE failed: %s", status.ToString().c_str());
            params[1].value.a = 1;
        }
        
        // Flush logs
        if (p2 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[2].memref.buffer && params[2].memref.size > 0) {
            ocall_log_flush_to_params(params[2].memref.buffer, &params[2].memref.size);
        }
        
        return TEE_SUCCESS;
        
    } catch (const std::exception& e) {
        OCALL_LOG("[EXCEPTION] %s", e.what());
        params[1].value.a = 1;
        
        if (p2 == TEE_PARAM_TYPE_MEMREF_OUTPUT && 
            params[2].memref.buffer && params[2].memref.size > 0) {
            ocall_log_flush_to_params(params[2].memref.buffer, &params[2].memref.size);
        }
        return TEE_ERROR_GENERIC;
    }
}

/*
 * Test writing a string to shared memory
 * 
 * params[0] = MEMREF_INOUT - Shared memory buffer
 * params[1] = MEMREF_OUTPUT - OCALL logs (optional)
 */
static TEE_Result test_shm_string(uint32_t param_types, TEE_Param params[4])
{
    OCALL_LOG("=== test_shm_string CALLED ===");
    
    uint32_t p0 = TEE_PARAM_TYPE_GET(param_types, 0);
    uint32_t p1 = TEE_PARAM_TYPE_GET(param_types, 1);
    
    OCALL_LOG("p0=0x%X, p1=0x%X", p0, p1);

    if (p0 != TEE_PARAM_TYPE_MEMREF_INOUT && p0 != TEE_PARAM_TYPE_MEMREF_OUTPUT) {
        OCALL_LOG("ERROR: Invalid param 0 type: 0x%X", p0);
        if (p1 == TEE_PARAM_TYPE_MEMREF_OUTPUT && params[1].memref.buffer) {
            ocall_log_flush_to_params(params[1].memref.buffer, &params[1].memref.size);
        }
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    if (!params[0].memref.buffer) {
        OCALL_LOG("ERROR: Invalid shared memory buffer");
        if (p1 == TEE_PARAM_TYPE_MEMREF_OUTPUT && params[1].memref.buffer) {
            ocall_log_flush_to_params(params[1].memref.buffer, &params[1].memref.size);
        }
        return TEE_ERROR_BAD_PARAMETERS;
    }
    
    const char* msg = "Hello from Secure World via Shared Memory!";
    size_t msg_len = strlen(msg) + 1; // Include null terminator
    
    if (params[0].memref.size < msg_len) {
        OCALL_LOG("ERROR: Shared memory too small! Need %zu, got %u", msg_len, params[0].memref.size);
        if (p1 == TEE_PARAM_TYPE_MEMREF_OUTPUT && params[1].memref.buffer) {
            ocall_log_flush_to_params(params[1].memref.buffer, &params[1].memref.size);
        }
        return TEE_ERROR_SHORT_BUFFER;
    }
    
    memcpy(params[0].memref.buffer, msg, msg_len);
    params[0].memref.size = msg_len;
    
    OCALL_LOG("Wrote message to shared memory: %s", msg);
    
    // Also write to ring buffer if available (check if it's large enough to be ring buffer)
    if (params[0].memref.size > 4096) {
        struct SharedRingBuffer* rb = static_cast<struct SharedRingBuffer*>(params[0].memref.buffer);
        char log_msg[256];
        snprintf(log_msg, sizeof(log_msg), "[RING] test_shm_string: %s\n", msg);
        write_to_ring_buffer(rb, log_msg, strlen(log_msg));
    }
    
    // Flush logs if requested
    if (p1 == TEE_PARAM_TYPE_MEMREF_OUTPUT && params[1].memref.buffer) {
        ocall_log_flush_to_params(params[1].memref.buffer, &params[1].memref.size);
    }
    
    return TEE_SUCCESS;
}
// =====================================================================
// TA Entry Points
// =====================================================================

TEE_Result TA_CreateEntryPoint(void)
{
    DMSG("has been called");
    ocall_log_init();
    return TEE_SUCCESS;
}

void TA_DestroyEntryPoint(void)
{
    DMSG("has been called");
    
    // Cleanup LevelDB
    if (g_db) {
        DMSG("Closing LevelDB");
        g_db.reset();
    }
    
    g_env.reset();
    g_producer.reset();
}

TEE_Result TA_OpenSessionEntryPoint(uint32_t param_types,
                                     TEE_Param __maybe_unused params[4],
                                     void __maybe_unused **sess_ctx)
{
    uint32_t exp_param_types = TEE_PARAM_TYPES(
        TEE_PARAM_TYPE_NONE,
        TEE_PARAM_TYPE_NONE,
        TEE_PARAM_TYPE_NONE,
        TEE_PARAM_TYPE_NONE);

    if (param_types != exp_param_types)
        return TEE_ERROR_BAD_PARAMETERS;

    IMSG("Session opened!");
    return TEE_SUCCESS;
}

void TA_CloseSessionEntryPoint(void __maybe_unused *sess_ctx)
{
    IMSG("Session closed");
}

TEE_Result TA_InvokeCommandEntryPoint(void __maybe_unused *sess_ctx,
                                       uint32_t cmd_id,
                                       uint32_t param_types,
                                       TEE_Param params[4])
{
    // Add try-catch to prevent crashes from propagating
    try {
        switch (cmd_id)
        {
        case TA_EEVM_CMD_TEST_SIMPLE_SHM:
            DMSG("Dispatching to test_simple_shm");
            return test_simple_shm(param_types, params);
        
        case TA_EEVM_CMD_INIT_LEVELDB:
            DMSG("Dispatching to leveldb_init");
            try {
                return leveldb_init(param_types, params);
            } catch (const std::exception& e) {
                DMSG("EXCEPTION in leveldb_init: %s", e.what());
                return TEE_ERROR_GENERIC;
            } catch (...) {
                DMSG("UNKNOWN EXCEPTION in leveldb_init");
                return TEE_ERROR_GENERIC;
            }
            
        case TA_EEVM_CMD_LEVELDB_PUT:
            DMSG("Dispatching to leveldb_put");
            return leveldb_put(param_types, params);
            
        case TA_EEVM_CMD_LEVELDB_GET:
            DMSG("Dispatching to leveldb_get");
            return leveldb_get(param_types, params);
        
        case TA_EEVM_CMD_LEVELDB_DELETE:
            DMSG("Dispatching to leveldb_delete");
            return leveldb_delete(param_types, params);

    case TA_EEVM_CMD_TEST_SHM_STRING:
        return test_shm_string(param_types, params);

        default:
            DMSG("ERROR: Unknown command: %u", cmd_id);
            return TEE_ERROR_BAD_PARAMETERS;
        }
    } catch (...) {
        DMSG("ERROR: Exception in TA_InvokeCommandEntryPoint for cmd_id=%u", cmd_id);
        return TEE_ERROR_GENERIC;
    }
}
