ocall_logger.o: ocall_logger.cpp include/ocall_logger.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stddef.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/string.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/features.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/strings.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdio.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdarg.h
