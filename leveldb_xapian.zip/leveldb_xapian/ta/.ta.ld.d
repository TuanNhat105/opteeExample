ta.lds: /home/orangepi/tee-core/export-ta_arm64/src/ta.ld.S
