ta.lds: /home/abc/optee_os/out/arm-plat-rpi5/export-ta_arm64/src/ta.ld.S
