leveldb_cpp/util/cache.o: leveldb_cpp/util/cache.cpp \
 ../leveldb/include/leveldb/cache.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdint \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__config \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/locale.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/features.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__config_original \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h \
 ../leveldb/include/leveldb/export.h ../leveldb/include/leveldb/slice.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cassert \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/assert.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstddef \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/version \
 /home/abc/arm-toolchain/lib/gcc/aarch64-none-linux-gnu/14.3.1/include/stddef.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__nullptr \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/type_traits \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstring \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/string.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/strings.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/string \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/string_view \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__string \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/algorithm \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/initializer_list \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/utility \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__tuple \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__debug \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/iosfwd \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/wchar.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/memory \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/typeinfo \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/exception \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdlib \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdlib.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/alloca.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/new \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/limits \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__undef_macros \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/iterator \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__functional_base \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/tuple \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/stdexcept \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/atomic \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/functional \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/bit \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdio \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdio.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cwchar \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cwctype \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cctype \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/ctype.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/wctype.h \
 ../leveldb/port/port.h ../leveldb/port/port_tee.h \
 ../leveldb/port/thread_annotations.h ../leveldb/util/hash.h \
 ../leveldb/util/mutexlock.h
../leveldb/include/leveldb/cache.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdint:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__config:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/locale.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/features.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__config_original:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h:
../leveldb/include/leveldb/export.h:
../leveldb/include/leveldb/slice.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cassert:
../../eevm_minimal_ta/build_oe_libs/musl/include/assert.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstddef:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/version:
/home/abc/arm-toolchain/lib/gcc/aarch64-none-linux-gnu/14.3.1/include/stddef.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__nullptr:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/type_traits:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstring:
../../eevm_minimal_ta/build_oe_libs/musl/include/string.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/strings.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/string:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/string_view:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__string:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/algorithm:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/initializer_list:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/utility:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__tuple:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__debug:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/iosfwd:
../../eevm_minimal_ta/build_oe_libs/musl/include/wchar.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/memory:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/typeinfo:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/exception:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdlib:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdlib.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/alloca.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/new:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/limits:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__undef_macros:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/iterator:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__functional_base:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/tuple:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/stdexcept:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/atomic:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/functional:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/bit:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdio:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdio.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cwchar:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cwctype:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cctype:
../../eevm_minimal_ta/build_oe_libs/musl/include/ctype.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/wctype.h:
../leveldb/port/port.h:
../leveldb/port/port_tee.h:
../leveldb/port/thread_annotations.h:
../leveldb/util/hash.h:
../leveldb/util/mutexlock.h:
