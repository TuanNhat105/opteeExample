leveldb_cpp/util/env_posix.o: leveldb_cpp/util/env_posix.cpp \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/dirent.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/features.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/fcntl.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/fcntl.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/pthread.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sched.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/time.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/mman.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/mman.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/resource.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/time.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/select.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/resource.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/stat.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stat.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/types.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/endian.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/__endian.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/sys/sysmacros.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/unistd.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/posix.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/atomic \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__config \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/locale.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__config_original \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstddef \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/version \
 /home/abc/arm-toolchain/lib/gcc/aarch64-none-linux-gnu/14.3.1/include/stddef.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__nullptr \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/type_traits \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdint \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cerrno \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/errno.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/errno.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdio \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdio.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdlib \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdlib.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/alloca.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstring \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/string.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/strings.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/limits \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__undef_macros \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/queue \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/deque \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__split_buffer \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/algorithm \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/initializer_list \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/utility \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__tuple \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__debug \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/iosfwd \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/wchar.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/memory \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/typeinfo \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/exception \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/new \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/iterator \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__functional_base \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/tuple \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/stdexcept \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/functional \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/bit \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/vector \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__bit_reference \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/climits \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/limits.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/bits/limits.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/set \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__tree \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__node_handle \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/optional \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/string \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/string_view \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__string \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cwchar \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cwctype \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cctype \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/ctype.h \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/wctype.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/thread \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/system_error \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__errc \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/chrono \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/ctime \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/ratio \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__mutex_base \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__threading_support \
 ../leveldb/include/leveldb/env.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdarg \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/stdarg.h \
 ../leveldb/include/leveldb/export.h ../leveldb/include/leveldb/status.h \
 ../leveldb/include/leveldb/slice.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/cassert \
 ../../eevm_minimal_ta/build_oe_libs/musl/include/assert.h \
 ../leveldb/port/port.h ../leveldb/port/port_tee.h \
 ../leveldb/port/thread_annotations.h \
 ../leveldb/util/env_posix_test_helper.h ../leveldb/util/posix_logger.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/sstream \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/ostream \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/ios \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__locale \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/mutex \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/streambuf \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/locale \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/__bsd_locale_fallbacks.h \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/bitset \
 ../../eevm_minimal_ta/build_oe_libs/libcxx/include/istream
../../eevm_minimal_ta/build_oe_libs/musl/include/dirent.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/features.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/alltypes.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/fcntl.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/fcntl.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/pthread.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sched.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/time.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/mman.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/mman.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/resource.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/time.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/select.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/resource.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/stat.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stat.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/types.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/endian.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/__endian.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdint.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/stdint.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/sys/sysmacros.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/unistd.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/posix.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/atomic:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__config:
../../eevm_minimal_ta/build_oe_libs/musl/include/locale.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__config_original:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstddef:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/version:
/home/abc/arm-toolchain/lib/gcc/aarch64-none-linux-gnu/14.3.1/include/stddef.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__nullptr:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/type_traits:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdint:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cerrno:
../../eevm_minimal_ta/build_oe_libs/musl/include/errno.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/errno.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdio:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdio.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdlib:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdlib.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/alloca.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstring:
../../eevm_minimal_ta/build_oe_libs/musl/include/string.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/strings.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/limits:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__undef_macros:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/queue:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/deque:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__split_buffer:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/algorithm:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/initializer_list:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/utility:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__tuple:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__debug:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/iosfwd:
../../eevm_minimal_ta/build_oe_libs/musl/include/wchar.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/memory:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/typeinfo:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/exception:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/new:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/iterator:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__functional_base:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/tuple:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/stdexcept:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/functional:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/bit:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/vector:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__bit_reference:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/climits:
../../eevm_minimal_ta/build_oe_libs/musl/include/limits.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/bits/limits.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/set:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__tree:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__node_handle:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/optional:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/string:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/string_view:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__string:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cwchar:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cwctype:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cctype:
../../eevm_minimal_ta/build_oe_libs/musl/include/ctype.h:
../../eevm_minimal_ta/build_oe_libs/musl/include/wctype.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/thread:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/system_error:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__errc:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/chrono:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/ctime:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/ratio:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__mutex_base:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__threading_support:
../leveldb/include/leveldb/env.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cstdarg:
../../eevm_minimal_ta/build_oe_libs/musl/include/stdarg.h:
../leveldb/include/leveldb/export.h:
../leveldb/include/leveldb/status.h:
../leveldb/include/leveldb/slice.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/cassert:
../../eevm_minimal_ta/build_oe_libs/musl/include/assert.h:
../leveldb/port/port.h:
../leveldb/port/port_tee.h:
../leveldb/port/thread_annotations.h:
../leveldb/util/env_posix_test_helper.h:
../leveldb/util/posix_logger.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/sstream:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/ostream:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/ios:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__locale:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/mutex:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/streambuf:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/locale:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/__bsd_locale_fallbacks.h:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/bitset:
../../eevm_minimal_ta/build_oe_libs/libcxx/include/istream:
